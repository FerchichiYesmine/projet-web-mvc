<?php 
// Inclusion du fichier de connexion à la base de données
include('database.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les valeurs envoyées par le formulaire
    $email = $_POST['email'];
    $motDePasse = $_POST['motDePasse'];

    // Requête SQL pour vérifier l'existence de l'utilisateur avec l'email
    $sql = "SELECT * FROM Etudiant WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Récupérer l'utilisateur
        $user = $result->fetch_assoc();

        // Vérifier le mot de passe haché avec password_verify()
        if (password_verify($motDePasse, $user['motDePasse'])) {

            session_start();
            $_SESSION['email'] = $email;
            header("Location: accueil.php");
            exit();
        } else {
            // Si les informations sont incorrectes, afficher un message d'erreur
            $errorMessage = "Email ou mot de passe incorrect.";
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2 class="text-center my-5">Connexion</h2>
        <form action="login.php" method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Entrez votre email" required>
            </div>
            <div class="form-group">
                <label for="motDePasse">Mot de passe</label>
                <input type="password" class="form-control" id="motDePasse" name="motDePasse" placeholder="Entrez votre mot de passe" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Se connecter</button>
        </form>
        <?php
        // Afficher l'erreur si les informations sont incorrectes
        if (isset($errorMessage)) {
            echo "<div class='alert alert-danger mt-3'>$errorMessage</div>";
        }
        ?>
    </div>
</body>
</html>
