<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Styles du menu transparent */
        .navbar {
            background: transparent !important;
            position: absolute;
            width: 100%;
            z-index: 1000;
            padding: 20px 0;
        }

        /* Section héro avec image de fond */
        .hero-section {
            height: 70vh;
            background: 
                linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('Improving Student-Led Discussions.jpg') center/cover;
            display: flex;
            align-items: center;
        }

        /* Styles texte */
        .navbar-brand, .nav-link {
            color: white !important;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }

        .nav-link:hover {
            color: #ddd !important;
        }

        /* Bouton connecter */
        .btn-connect {
            background: rgba(255,255,255,0.2);
            border: 2px solid white;
            color: white !important;
        }

        /* Section calendrier */
        .calendar-section {
            padding: 80px 0;
            background: #f8f9fa;
        }

        /* Footer */
        .footer {
            background: #2c3e50;
            color: white;
            padding: 40px 0;
        }

        .footer a {
            color: #ecf0f1;
            text-decoration: none;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .navbar {
                background: rgba(0,0,0,0.7) !important;
            }
            .hero-section {
                height: 50vh;
            }
        }
    </style>
</head>
<body>

<!-- Menu Transparent -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#">ClubManager</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Acceuil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="clubs.html">Clubs</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://docs.google.com/forms/d/e/1FAIpQLSd4XvCArCU5WgZWOe9CQ8wFn3J0CrYS1wFPvBpR0xZIA-nTFQ/viewform?usp=header">Demandes</a>
                </li>
                <li class="nav-item ms-3">
                    <a href="inscription.php" class="btn btn-connect">Se connecter</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Section Hero -->
<section class="hero-section">
    <div class="container">
        <div class="text-center text-white">
            <h1 class="display-3 mb-4">Gestion des Clubs</h1>
            <p class="lead">Organisez vos activités étudiantes</p>
        </div>
    </div>
</section>

<!-- Section Calendrier -->
<section class="calendar-section">
    <div class="container">
        <h2 class="text-center mb-5">Calendrier des Événements</h2>
        <div class="row g-4">
            <!-- Événement 1 -->
            <div class="col-md-4">
                <div class="event-card bg-primary text-white p-4 rounded-3 shadow">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="badge bg-white text-primary">25 mars</div>
                        <div class="text-small">10h00</div>
                    </div>
                    <h4>Réunion générale</h4>
                    <p class="mb-0">Amphi A</p>
                </div>
            </div>

            <!-- Événement 2 -->
            <div class="col-md-4">
                <div class="event-card bg-success text-white p-4 rounded-3 shadow">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="badge bg-white text-success">28 mars</div>
                        <div class="text-small">14h30</div>
                    </div>
                    <h4>Atelier programmation</h4>
                    <p class="mb-0">amphi 2</p>
                </div>
            </div>

            <!-- Événement 3 -->
            <div class="col-md-4">
                <div class="event-card bg-warning text-dark p-4 rounded-3 shadow">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div class="badge bg-white text-warning">02 avril</div>
                        <div class="text-small">09h00</div>
                    </div>
                    <h4>Présentation projets</h4>
                    <p class="mb-0">Espace créatif</p>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
 
.event-card {
    transition: all 0.3s ease;
    height: 200px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.event-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.15);
}

.badge {
    padding: 8px 12px;
    border-radius: 20px;
    font-weight: 600;
}

.text-small {
    font-size: 0.9em;
    opacity: 0.9;
}
</style>

<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5>Contact</h5>
                <p class="mt-3">
                    Université de tunis<br>
                    montfleury <br>
                    
                </p>
            </div>
            
            <div class="col-md-4 mb-4">
                <h5>Navigation</h5>
                <ul class="list-unstyled mt-3">
                    <li class="mb-2">
                        <a href="#">Acceuil</a>
                    </li>
                    <li class="mb-2">
                        <a href="#">Clubs</a>
                    </li>
                    <li class="mb-2">
                        <a href="#">Demandes</a>
                    </li>
                </ul>
            </div>
            
            <div class="col-md-4 mb-4">
                <h5>Réseaux Sociaux</h5>
                <div class="mt-3">
                    <a href="#" class="me-3">Facebook</a>
                    <a href="#" class="me-3">Twitter</a>
                    <a href="#">Instagram</a>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
