<?php
// Inclusion du fichier de connexion
include('database.php');

$errorMessage = ""; // Initialisation du message d'erreur

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer et nettoyer les valeurs envoyées par le formulaire
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $email = trim($_POST['email']);
    $motDePasse = $_POST['motDePasse'];

    // Validation de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Format d'email invalide.";
    } elseif (strlen($motDePasse) < 6) { // Vérification longueur du mot de passe
        $errorMessage = "Le mot de passe doit contenir au moins 6 caractères.";
    } else {
        // Vérifier si l'email existe déjà
        $checkEmail = "SELECT id FROM Etudiant WHERE email = ?";
        $stmt = $conn->prepare($checkEmail);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errorMessage = "Cet email est déjà utilisé.";
        } else {
            // Hachage du mot de passe
            $hashedPassword = password_hash($motDePasse, PASSWORD_DEFAULT);

            // Insérer l'utilisateur dans la base de données
            $sql = "INSERT INTO Etudiant (nom, prenom, email, motDePasse, dateInscription) VALUES (?, ?, ?, ?, NOW())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $nom, $prenom, $email, $hashedPassword);

            if ($stmt->execute()) {
                // Fermer la connexion et rediriger vers la page de connexion
                $stmt->close();
                $conn->close();
                header("Location: login.php");
                exit();
            } else {
                $errorMessage = "Erreur lors de l'inscription.";
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2 class="text-center my-5">Créer un compte</h2>
        
        <?php if (!empty($errorMessage)) : ?>
            <div class="alert alert-danger text-center"><?= htmlspecialchars($errorMessage); ?></div>
        <?php endif; ?>

        <form action="inscription.php" method="post">
            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" required>
            </div>
            <div class="form-group">
                <label for="prenom">Prénom</label>
                <input type="text" class="form-control" id="prenom" name="prenom" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="motDePasse">Mot de passe</label>
                <input type="password" class="form-control" id="motDePasse" name="motDePasse" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">S'inscrire</button>
        </form>

        <p class="text-center mt-3"> Déjà un compte ? <a href="login.php">Connectez-vous</a></p>
        <a href="admin_connexion.php" class="btn btn-link text-muted">Connexion administrateur</a>
    </div>
</body>
</html>
