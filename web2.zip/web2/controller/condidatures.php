<?php  
include 'database.php'; // Connexion à la BDD  

// Vérifier si une action est envoyée et l'idCandidature est défini
if (isset($_POST['action']) && isset($_POST['idCandidature'])) {  
    $idCandidature = $_POST['idCandidature'];  
    $action = $_POST['action']; // 'acceptée' ou 'refusée'  

    if ($action == 'acceptée') {  
        // Récupérer l'étudiant et le club  
        $query = $conn->prepare("SELECT idEtudiant, idClub FROM Candidature WHERE id = ?");  
        $query->execute([$idCandidature]);  
        $candidature = $query->fetch();  
  
        if ($candidature) {  
            $idEtudiant = $candidature['idEtudiant'];  
            $idClub = $candidature['idClub'];  
  
            // Ajouter l'étudiant à la table Membre  
            $query = $conn->prepare("INSERT INTO Membre (idEtudiant, idClub) VALUES (?, ?)");  
            if ($query->execute([$idEtudiant, $idClub])) {
                // Mettre à jour le statut de la candidature  
                $query = $conn->prepare("UPDATE Candidature SET statut = 'acceptée' WHERE id = ?");  
                if ($query->execute([$idCandidature])) {
                    // Mettre à jour le nombre de membres du club  
                    $query = $conn->prepare("UPDATE Club SET nombreMembres = nombreMembres + 1 WHERE id = ?");  
                    $query->execute([$idClub]);
                    echo "La candidature a été acceptée et l'étudiant ajouté au club.";
                }
            } else {
                echo "Erreur lors de l'ajout de l'étudiant au club.";
            }
        }  
    } elseif ($action == 'refusée') {  
        // Mettre à jour seulement le statut  
        $query = $conn->prepare("UPDATE Candidature SET statut = 'refusée' WHERE id = ?");  
        if ($query->execute([$idCandidature])) {
            echo "La candidature a été refusée.";
        } else {
            echo "Erreur lors du refus de la candidature.";
        }
    }  
}  
  
// Récupérer toutes les candidatures en attente  
$query = $conn->query("SELECT Candidature.id, Etudiant.nom, Etudiant.prenom, Club.nom AS club_nom, Candidature.statut   
    FROM Candidature  
    JOIN Etudiant ON Candidature.idEtudiant = Etudiant.id  
    JOIN Club ON Candidature.idClub = Club.id  
    WHERE Candidature.statut = 'en attente'");  
$candidatures = $query->fetchAll();  
?>  

<!DOCTYPE html>  
<html lang="fr">  
<head>  
    <meta charset="UTF-8">  
    <title>Gestion des candidatures</title>  
</head>  
<body>  
    <h2>Liste des candidatures</h2>  
    <table border="1">  
        <tr>  
            <th>Nom</th>  
            <th>Prénom</th>  
            <th>Club</th>  
            <th>Statut</th>  
            <th>Actions</th>  
        </tr>  
        <?php foreach ($candidatures as $candidature): ?>  
            <tr>  
                <td><?= $candidature['nom'] ?></td>  
                <td><?= $candidature['prenom'] ?></td>  
                <td><?= $candidature['club_nom'] ?></td>  
                <td><?= $candidature['statut'] ?></td>  
                <td>  
                    <form method="POST">  
                        <input type="hidden" name="idCandidature" value="<?= $candidature['id'] ?>">  
                        <button type="submit" name="action" value="acceptée">Accepter</button>  
                        <button type="submit" name="action" value="refusée">Refuser</button>  
                    </form>  
                </td>
            </tr>  
        <?php endforeach; ?>  
    </table>  
</body>  
</html>
