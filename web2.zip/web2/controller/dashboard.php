<?php
// Vérifier si l'utilisateur est un admin
session_start(); // Si vous utilisez des sessions pour vérifier l'authentification

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Rediriger si non connecté en tant qu'admin
    exit;
}


include ('database.php');

$query = $conn->query("SELECT * FROM Candidature");
$candidatures = $query->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Gestion des Candidatures</title>
</head>
<body>
    <h1>Tableau de Bord - Candidatures</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Club</th>
                <th>Statut</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($candidatures as $candidature): ?>
                <tr>
                    <td><?= $candidature['nom'] ?></td>
                    <td><?= $candidature['prenom'] ?></td>
                    <td><?= $candidature['club_nom'] ?></td>
                    <td><?= $candidature['statut'] ?></td>
                    <td>
                        <!-- Formulaire pour accepter ou refuser -->
                        <form method="POST">
                            <input type="hidden" name="idCandidature" value="<?= $candidature['id'] ?>">
                            <button type="submit" name="action" value="acceptée">Accepter</button>
                            <button type="submit" name="action" value="refusée">Refuser</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
