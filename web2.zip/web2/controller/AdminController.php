<?php
session_start();
include('database.php'); // Assure-toi que le chemin est correct !

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['action']) && $_POST['action'] === 'seConnecterAdmin') {
        $email = $_POST['email'];  // Utilise "email" au lieu de "identifiant"
        $motDePasse = $_POST['motDePasse'];

        // Préparer la requête SQL pour vérifier les identifiants admin
        $sql = "SELECT * FROM admin WHERE email = ?"; // Vérifie que "email" est correct dans la base
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email); // Liaison du paramètre "email"
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $admin = $result->fetch_assoc();
            // Vérifie le mot de passe
            if (password_verify($motDePasse, $admin['motDePasse'])) {
                $_SESSION['admin'] = $admin['id'];  // Sauvegarde l'ID de l'admin dans la session
                echo "Connexion admin réussie";  // Message de succès
            } else {
                echo "Mot de passe incorrect.";
            }
        } else {
            echo "Email incorrect.";
        }
    } else {
        echo "Requête invalide.";
    }
} else {
    echo "Méthode non autorisée.";
}
?>
