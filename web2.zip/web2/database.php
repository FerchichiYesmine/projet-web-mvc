<?php
$host = "localhost"; 
$user = "root"; 
$password = ""; 
$database = "gestion_clubs"; 

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}
?>
