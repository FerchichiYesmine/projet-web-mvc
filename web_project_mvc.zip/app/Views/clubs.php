<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Détails du Club</title>
    <!-- Bootstrap CSS + Font Awesome pour les icônes -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
      .club-header {
    background-image: 
        linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), /* Dégradé sombre par-dessus */
        url('logo-club.png'); /* Chemin de votre logo carré */
    background-size: 100px 100px; /* Taille des carreaux */
    background-repeat: repeat; /* Répétition du motif */
    min-height: 300px;
    border-radius: 15px;
    position: relative;
}

        .social-links a {
            font-size: 1.5rem;
            margin: 0 10px;
            transition: transform 0.3s;
        }
        .social-links a:hover {
            transform: translateY(-3px);
        }
    </style>
</head>
<body>
    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.html">ESSECT Clubs</a>
    </nav>

    <div class="container my-5">
        <!-- En-tête du club -->
        <div class="club-header bg-dark text-white p-4 mb-4" style="background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('483285079_551944653982392_941433393726587831_n.jpg');">
            <h1 class="display-4">InfoLab</h1>
            <div class="badge badge-primary p-2">Fondé en 2020</div>
        </div>

        <!-- Contenu principal -->
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-4">À propos du club</h2>
                <p class="lead">Le club Infolab est dédié à l'innovation et à la technologie. Il offre un espace pour les étudiants intéressés par le développement informatique, la gestion de projets tech, et la découverte des dernières tendances numériques. Ce club organise des ateliers, des hackathons, et des formations sur divers outils et langages de programmation, tout en favorisant l’esprit d’équipe et de collaboration.</p>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-info-circle"></i> Détails</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Date de fondation:</strong> 15 Mars 2020
                            </li>
                            <li class="list-group-item">
                                <strong>Nombre de membres:</strong> 45
                            </li>
                            <li class="list-group-item">
                                <strong>Président:</strong> nour cherni
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Sidebar avec les réseaux sociaux -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h4 class="card-title mb-4">Nous suivre</h4>
                        <div class="social-links">
                            <a href="https://www.facebook.com/share/16B5Wos6yH/" class="text-primary" target="_blank">
                                <i class="fab fa-facebook"></i>
                            </a>
                            <a href="https://www.instagram.com/infolab_essect/" class="text-danger" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://www.tiktok.com/@infolabessect?_t=ZM-8uhj6kyKsv0&_r=1" class="text-info" target="_blank">
                                <i class="fab fa-tiktok"></i>
                            </a>
                             
                        </div>
                    </div>
                </div>

                 
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <div class="container my-5">
        <!-- En-tête du club -->
        <div class="club-header bg-dark text-white p-4 mb-4" style="background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(' 579a206d-5798-4b16-bf89-548051edde60.jpg');">
            <h1 class="display-4">enactus</h1>
            <div class="badge badge-primary p-2">Fondé en 2017</div>
        </div>

        <!-- Contenu principal -->
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-4">À propos du club</h2>
                <p class="lead"> Enactus est un club qui vise à encourager l'entrepreneuriat social. Enactus ESSECT soutient des projets qui ont un impact positif sur la société, tout en offrant aux étudiants une expérience pratique dans le domaine de l'entrepreneuriat et du développement durable. Ce club participe à des compétitions nationales et internationales où les étudiants présentent leurs initiatives sociales et entrepreneuriales..</p>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-info-circle"></i> Détails</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Date de fondation:</strong> 17 avril 2017
                            </li>
                            <li class="list-group-item">
                                <strong>Nombre de membres:</strong> 61
                            </li>
                            <li class="list-group-item">
                                <strong>Président:</strong> .
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Sidebar avec les réseaux sociaux -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h4 class="card-title mb-4">Nous suivre</h4>
                        <div class="social-links">
                            <a href="https://www.facebook.com/share/159iRZBLGw/" class="text-primary" target="_blank">
                                <i class="fab fa-facebook"></i>
                            </a>
                            <a href="https://www.instagram.com/enactors.essect?igsh=MThzb2trYmE2a216NA==" class="text-danger" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://www.tiktok.com/@enactus_essect?_t=ZM-8uhj9wWqIvG&_r=1" class="text-info" target="_blank">
                                <i class="fab fa-tiktok"></i>
                            </a>
                             
                        </div>
                    </div>
                </div>

                 
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <div class="container my-5">
        <!-- En-tête du club -->
        <div class="club-header bg-dark text-white p-4 mb-4" style="background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(' 483026169_3621313524841020_2830091822277132582_n.jpg');">
            <h1 class="display-4">fahmolougia</h1>
            <div class="badge badge-primary p-2">Fondé en 2021</div>
        </div>

        <!-- Contenu principal -->
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-4">À propos du club</h2>
                <p class="lead">Fahmologia est un club culturel et intellectuel de l’ESSECT qui se concentre sur l'enrichissement des connaissances des étudiants à travers des conférences, des débats, et des événements culturels. Il vise à promouvoir la réflexion critique, le développement personnel, et la sensibilisation à des sujets sociaux, politiques et culturels actuels. Les membres de Fahmologia participent activement à l'organisation de forums et de rencontres avec des experts invités.</p>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-info-circle"></i> Détails</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Date de fondation:</strong> 21 janvier 2021
                            </li>
                            <li class="list-group-item">
                                <strong>Nombre de membres:</strong> 32
                            </li>
                            <li class="list-group-item">
                                <strong>Président:</strong> chaima benour
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Sidebar avec les réseaux sociaux -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h4 class="card-title mb-4">Nous suivre</h4>
                        <div class="social-links">
                            <a href="https://www.facebook.com/share/1XNHWCPLDe/" class="text-primary" target="_blank">
                                <i class="fab fa-facebook"></i>
                            </a>
                            
                            <a href="https://www.tiktok.com/@fahmologiaessect?_t=ZM-8uhj2fyv10f&_r=1" class="text-info" target="_blank">
                                <i class="fab fa-tiktok"></i>
                            </a>
                             
                            
                        </div>
                    </div>
                </div>

                 
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <div class="container my-5">
        <!-- En-tête du club -->
        <div class="club-header bg-dark text-white p-4 mb-4" style="background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('56df1326-0475-49c8-8354-5714e7d660b5.jpg');">
            <h1 class="display-4">club radio</h1>
            <div class="badge badge-primary p-2">Fondé en 2025</div>
        </div>

        <!-- Contenu principal -->
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-4">À propos du club</h2>
                <p class="lead">Le club Radio ESSECT FM est l’occasion pour les étudiants passionnés de médias et de communication de s'impliquer dans la production radiophonique. Les membres du club gèrent la station de radio de l'ESSECT, créent des émissions sur divers sujets (musique, actualités, culture, événements scolaires), et développent des compétences en gestion des médias et en communication audiovisuelle.</p>
                
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-info-circle"></i> Détails</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <strong>Date de fondation:</strong> 21 fevrier 2025
                            </li>
                            <li class="list-group-item">
                                <strong>Nombre de membres:</strong> 27
                            </li>
                            <li class="list-group-item">
                                <strong>Président:</strong> amin salhi
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Sidebar avec les réseaux sociaux -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h4 class="card-title mb-4">Nous suivre</h4>
                        <div class="social-links">
                            <a href="https://www.facebook.com/share/15oKaKG82Q/" class="text-primary" target="_blank">
                                <i class="fab fa-facebook"></i>
                            </a>
                             
                        </div>
                    </div>
                </div>

                
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>