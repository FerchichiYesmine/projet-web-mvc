<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion Admin</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Barre de navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.html">ESSECT Clubs</a>
    </nav>

    <!-- Formulaire de connexion admin -->
    <div class="container mt-5">
        <h1 class="text-center text-danger">Espace Administrateur</h1>
        <div class="alert alert-warning mt-3">
            Réservé au personnel autorisé uniquement
        </div>
        
        <form id="adminConnexionForm">
            <div class="form-group">
                <label for="adminIdentifiant">Identifiant Admin</label>
                <input type="text" class="form-control" id="adminIdentifiant" name="adminIdentifiant" required>
            </div>
            <div class="form-group">
                <label for="adminMotDePasse">Mot de passe</label>
                <input type="password" class="form-control" id="adminMotDePasse" name="adminMotDePasse" required>
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="rememberMe">
                <label class="form-check-label" for="rememberMe">Se souvenir de moi</label>
            </div>
            <button type="submit" class="btn btn-danger btn-block">Connexion Admin</button>
            
            <div class="text-center mt-3">
                <a href="connexion.html" class="btn btn-link">Connexion utilisateur standard</a>
            </div>
        </form>
    </div>

    <!-- jQuery et Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $('#adminConnexionForm').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                url: 'controllers/AdminController.php',
                type: 'POST',
                data: {
                    action: 'seConnecterAdmin',
                    identifiant: $('#adminIdentifiant').val(),
                    motDePasse: $('#adminMotDePasse').val()
                },
                success: function(response) {
                    if (response === "Connexion admin réussie") {
                        window.location.href = 'admin_dashboard.html';
                    } else {
                        alert("Erreur : " + response);
                    }
                },
                error: function(xhr) {
                    alert("Erreur technique : " + xhr.statusText);
                }
            });
        });
    </script>
</body>
</html>