<?php
// Inclusion du fichier de connexion
include('database.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les valeurs envoyées par le formulaire
    $email = $_POST['email'];
    $motDePasse = $_POST['motDePasse'];

    // Requête SQL pour vérifier les identifiants
    $sql = "SELECT * FROM Etudiant WHERE email = ? AND motDePasse = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $motDePasse); // "ss" pour deux chaînes de caractères
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Si un utilisateur est trouvé, démarrer la session et rediriger vers la page d'accueil
        session_start();
        $_SESSION['email'] = $email;
        header("Location: accueil.php");
        exit();
    } else {
        // Si les informations sont incorrectes, afficher un message d'erreur
        $errorMessage = "Email ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2 class="text-center my-5">Connexion</h2>
        <form action="login.php" method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Entrez votre email" required>
            </div>
            <div class="form-group">
                <label for="motDePasse">Mot de passe</label>
                <input type="password" class="form-control" id="motDePasse" name="motDePasse" placeholder="Entrez votre mot de passe" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Se connecter</button>
        </form>
        <?php
        // Afficher l'erreur si les informations sont incorrectes
        if (isset($errorMessage)) {
            echo "<div class='alert alert-danger mt-3'>$errorMessage</div>";
        }
        ?>
    </div>
</body>
</html>
